public class InvalidAmountException extends Exception {
    public InvalidAmountException(String message) {
        super(message);  // Passing the message to the superclass (Exception)
    }
}
