import java.util.InputMismatchException;
import java.util.Scanner;

public class BankApplication {

    // Nested Exception Classes
    static class InvalidAmountException extends Exception {
        public InvalidAmountException(String message) {
            super(message);
        }
    }

    static class InsufficientFundsException extends Exception {
        public InsufficientFundsException(String message) {
            super(message);
        }
    }

    // Nested BankAccount Class
    static class BankAccount {
        private String accountHolderName;
        private double balance;

        public BankAccount(String accountHolderName) {
            this.accountHolderName = accountHolderName;
            this.balance = 0.0;
        }

        public void deposit(double amount) throws InvalidAmountException {
            if (amount <= 0) {
                throw new InvalidAmountException("Deposit amount must be greater than zero.");
            }
            balance += amount;
            System.out.println("Deposited ₹" + amount + " successfully.");
        }

        public void withdraw(double amount) throws InvalidAmountException, InsufficientFundsException {
            if (amount <= 0) {
                throw new InvalidAmountException("Withdrawal amount must be greater than zero.");
            }
            if (amount > balance) {
                throw new InsufficientFundsException("Insufficient balance! Available balance: ₹" + balance);
            }
            balance -= amount;
            System.out.println("Withdrawn ₹" + amount + " successfully.");
        }

        public void viewBalance() {
            System.out.println(accountHolderName + ", your current balance is: ₹" + balance);
        }
    }

    // Main Method
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BankAccount account = null;

        try {
            System.out.println("Welcome to Online Bank Account Management System!");
            System.out.print("Enter your name to create an account: ");
            String name = scanner.nextLine();
            account = new BankAccount(name);

            int choice = 0;
            do {
                System.out.println("\n========= Menu =========");
                System.out.println("1. Deposit Money");
                System.out.println("2. Withdraw Money");
                System.out.println("3. View Balance");
                System.out.println("4. Exit");
                System.out.print("Enter your choice: ");

                try {
                    choice = scanner.nextInt();

                    switch (choice) {
                        case 1:
                            System.out.print("Enter amount to deposit: ₹");
                            double depositAmount = scanner.nextDouble();
                            account.deposit(depositAmount);
                            break;
                        case 2:
                            System.out.print("Enter amount to withdraw: ₹");
                            double withdrawAmount = scanner.nextDouble();
                            account.withdraw(withdrawAmount);
                            break;
                        case 3:
                            account.viewBalance();
                            break;
                        case 4:
                            System.out.println("Thank you for using the bank. Goodbye!");
                            break;
                        default:
                            System.out.println("Invalid choice. Please select between 1-4.");
                    }
                } catch (InputMismatchException e) {
                    System.out.println("Invalid input! Please enter a number.");
                    scanner.nextLine(); // clear buffer
                    choice = 0;
                } catch (InvalidAmountException | InsufficientFundsException e) {
                    System.out.println("Error: " + e.getMessage());
                } catch (Exception e) {
                    System.out.println("Something went wrong: " + e.getMessage());
                }

            } while (account != null && choice != 4);

        } finally {
            System.out.println("\nClosing resources...");
            scanner.close();
        }
    }
}
